const corgisFacts = [
  "Corgis were originally bred for herding cattle and sheep in Wales!",
  "An adult Pembroke Welsh Corgi typically weighs between 10-12 kg.",
  "Corgis stand about 25-30 cm tall at the shoulder.",
  "Despite their small size, Corgis can run at speeds up to 40 km/h!",
  "A Corgi's typical body length is about 45-50 cm, not including their tail.",
  "Corgis have a double coat that typically sheds twice a year.",
  "The average Corgi needs about 1.5-2 km of walking daily for exercise.",
  "Cardigan Welsh Corgis are slightly larger, weighing up to 17 kg.",
  "A healthy Corgi can jump up to 45 cm high despite their short legs.",
  "Corgis have a life expectancy of 12-15 years.",
  "The ideal temperature range for Corgis is 15-25°C.",
  "Corgi puppies typically weigh 0.2-0.3 kg at birth.",
  "The breed was recognized by the Kennel Club in the UK in 1925.",
  "Corgis are known for their 'fairy saddle' marking, caused by a change in thickness and direction of their coat.",
  "Pembroke Welsh Corgis have averaged 4-6 puppies per litter.",
  "Their short legs are a result of achondroplasia, a form of dwarfism.",
  "A Corgi's ears can detect sounds up to 16 meters away!",
  "Corgis were originally used to herd animals by nipping at their heels.",
  "The typical Corgi brain weighs about 65 grams.",
  "A Corgi's bark can reach volumes of up to 80 decibels.",
  "During peak shedding seasons, Corgis can lose up to 30 grams of fur per day.",
  "In Welsh folklore, Corgis were said to be the preferred mount of fairy warriors.",
  "The breed requires about 1000-1200 calories per day depending on activity level.",
  "Corgis have excellent depth perception up to 6 meters away.",
  "Queen Elizabeth II's first Corgi, Susan, was given to her on her 18th birthday.",
  "Corgis have a body temperature of about 38.5°C, typical for dogs.",
  "The breed has been documented in Wales since at least 1107 CE.",
  "Corgis can turn their heads up to 120 degrees to each side.",
  "A Corgi's paw print is typically about 3.5 cm wide.",
  "The average Corgi drinks about 0.5-1 liter of water daily.",
];

function getRandomCorgiFact() {
  return corgisFacts[Math.floor(Math.random() * corgisFacts.length)];
}

function createCorgiElement() {
  const div = document.createElement("div");
  div.className = "corgi-fact";
  // Rosé Pine theme colors and styling
  div.style.cssText = `
    padding: 16px;
    margin: 12px 0;
    background-color: #191724;
    border: 1px solid #26233a;
    border-radius: 10px;
    color: #e0def4;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
    line-height: 1.5;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: all 0.2s ease;
  `;

  const emoji = document.createElement("span");
  emoji.style.marginRight = "8px";
  emoji.textContent = "🐕";

  const text = document.createElement("span");
  text.style.color = "#e0def4";
  text.textContent = `Corgi Fact: ${getRandomCorgiFact()}`;

  div.appendChild(emoji);
  div.appendChild(text);

  // Hover effect
  div.addEventListener("mouseover", () => {
    div.style.backgroundColor = "#1f1d2e";
    div.style.borderColor = "#31748f";
  });

  div.addEventListener("mouseout", () => {
    div.style.backgroundColor = "#191724";
    div.style.borderColor = "#26233a";
  });

  return div;
}

function filterMuskPosts() {
  const posts = document.querySelectorAll("article");

  posts.forEach((post) => {
    const postText = post.textContent.toLowerCase();
    if (
      postText.includes("@elonmusk") ||
      postText.includes("elon musk") ||
      postText.includes("@x")
    ) {
      const corgiElement = createCorgiElement();
      post.replaceWith(corgiElement);
    }
  });
}

// Initial filter
filterMuskPosts();

// Set up observer to handle dynamically loaded content
const observer = new MutationObserver((mutations) => {
  filterMuskPosts();
});

// Start observing
observer.observe(document.body, {
  childList: true,
  subtree: true,
});
